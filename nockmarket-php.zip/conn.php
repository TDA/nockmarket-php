<?php

$dbconn= mysqli_connect('localhost','root','pass','nockbase') or die('connection error');

?>